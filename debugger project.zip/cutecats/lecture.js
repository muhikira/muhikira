function foo(word){
    debugger;
    console.log(word)
    bar("barber")
}

function bar(word){
    debugger;
    console.log(word)
    baz("bazaar")
}
function baz(word){
    debugger;
    console.log(word)
}
foo('food')
