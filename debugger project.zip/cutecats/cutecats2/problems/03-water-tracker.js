/*

Fix the function `adequateWaterTracker`. `adequateWaterTracker` should return
true if ALL the the weeks in the calendar array having more days in the week
that you drank water than you didn't.

For example, in this week, [0, 0, 3, 1, 0, 4, 0], each day represents how many
cups of water you drank that day. In this example, there were only 3 days where
you drank at least one cup of water.

A calendar is represented by multiple weeks,
[[0, 0, 3, 1, 0, 4, 0], [1, 2, 1, 2, 1, 3, 1]].

If you drank water for at least 4 days of water for every week in the calendar,
then return true. Otherwise, return false.

*/
//True if ALL the weeks in the calender array have more days in the week than you drank water than you didn't.

function adequateWaterTracker(calendar) {
  for (let i = 0; i < calendar.length; i++) { //<--- It's iterating through the week
    let noWater = 0;      // <-- We put water + noWater inside this Week Loop so that we can "reset" it every week.
    let water = 0;       //
    let week = calendar[i]; // Lets us put the current Week, so that we can see inside every "day"
    for (let j = 0; j < week.length; j++) { //This loop lets us see every "day" inside each week.
      let day = week[j]; // Assigns
      if (day === 0) {
        noWater++;
      } else {
        water++;
      }
      }
      if (noWater >= 4){      //Checking to see if the array has more than 4 no water days
        return false    //If it does, it's automatically alse
      }
    }
  return true; //If no more than four water days, than that means both are OK.
}



//We need to put these two counters into an object.


//If (First Array water is > 4 && if SecondArray Water is > 4)
const calendar1 = [
  [0, 0, 3, 1, 0, 4, 0],
  [1, 2, 1, 2, 1, 3, 1],
];

console.log(adequateWaterTracker(calendar1)); // false
debugger;
const calendar2 = [
  [1, 1, 1, 1, 1, 1, 1],
  [0, 0, 0, 0, 0, 1, 1],
];

console.log(adequateWaterTracker(calendar2)); // false

const calendar3 = [
  [1, 1, 1, 1, 0, 0, 0],
  [1, 1, 1, 1, 0, 0, 0],
];

console.log(adequateWaterTracker(calendar3)); // true
